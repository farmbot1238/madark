// ===== MADARIK.JO — MAIN SCRIPTS =====

// Generate stars
document.addEventListener('DOMContentLoaded', function () {
  const container = document.getElementById('starsContainer');
  if (container) {
    for (let i = 0; i < 80; i++) {
      const s = document.createElement('div');
      s.className = 'star';
      const size = Math.random() * 2.5 + 0.5;
      s.style.cssText = `width:${size}px;height:${size}px;top:${Math.random() * 100}%;left:${Math.random() * 100}%;--d:${(Math.random() * 4 + 2).toFixed(1)}s;--delay:${(Math.random() * 5).toFixed(1)}s`;
      container.appendChild(s);
    }
  }

  // Iframe load event
  const iframe = document.getElementById('mainIframe');
  if (iframe) {
    iframe.addEventListener('load', function () {
      document.getElementById('viewerSpinner').style.display = 'none';
      this.style.opacity = '1';
      this.style.transition = 'opacity 0.3s';
    });
  }
});

// ---- Navigation ----
function toggleFaq(el) {
  el.classList.toggle('open');
}

function go2009() {
  document.getElementById('landing').style.display = 'none';
  document.getElementById('page2009').classList.add('active');
  window.scrollTo(0, 0);
}

function goBack() {
  document.getElementById('page2009').classList.remove('active');
  document.getElementById('landing').style.display = 'flex';
  closeSidebar();
  resetIframe();
  window.scrollTo(0, 0);
}

function show2010Modal() {
  document.getElementById('constructionModal').classList.add('show');
}

function closeModal(e) {
  if (e.target.id === 'constructionModal') {
    document.getElementById('constructionModal').classList.remove('show');
  }
}

// ---- Sidebar ----
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('show');
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('show');
}

// ---- Viewer / iFrame ----
let currentLink = null;

function loadFrame(url, title, linkEl) {
  closeSidebar();
  if (currentLink) currentLink.classList.remove('active');
  linkEl.classList.add('active');
  currentLink = linkEl;

  const viewer = document.getElementById('fullViewer');
  const iframe = document.getElementById('mainIframe');
  const titleEl = document.getElementById('viewerTitle');
  const spinner = document.getElementById('viewerSpinner');

  titleEl.textContent = title;
  spinner.style.display = 'block';
  iframe.style.opacity = '0';
  iframe.src = url;
  viewer.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeViewer() {
  const viewer = document.getElementById('fullViewer');
  const iframe = document.getElementById('mainIframe');
  viewer.style.display = 'none';
  iframe.src = 'about:blank';
  document.body.style.overflow = '';
  if (currentLink) { currentLink.classList.remove('active'); currentLink = null; }
}

function openNewTab(url) {
  closeSidebar();
  window.open(url, '_blank', 'noopener,noreferrer');
}

function resetIframe() {
  closeViewer();
}

// ---- Email copy ----
function copyEmail() {
  navigator.clipboard.writeText('abdalrhmanmaaith1@gmail.com').then(() => {
    alert('تم نسخ البريد الإلكتروني ✓');
  });
  closeSidebar();
}

// ---- Chat Rules Modal ----
// Use localStorage so acceptance survives page refresh
let chatRulesAccepted = localStorage.getItem('chatRulesAccepted') === 'true';

function openChatWithRules(linkEl) {
  closeSidebar();
  if (chatRulesAccepted) {
    // Open chat in iframe inside the viewer
    loadFrame('https://cooperate-and-conquer.lovable.app', 'الدردشة الدراسية', linkEl);
    return;
  }
  // Save reference to open after acceptance
  window._pendingChatLink = linkEl;
  document.getElementById('chatRulesModal').style.display = 'flex';
}

function acceptChat() {
  chatRulesAccepted = true;
  localStorage.setItem('chatRulesAccepted', 'true');
  document.getElementById('chatRulesModal').style.display = 'none';
  // Open in iframe
  const linkEl = window._pendingChatLink || document.querySelector('[data-chat-link]');
  loadFrame('https://cooperate-and-conquer.lovable.app', 'الدردشة الدراسية', linkEl || document.body);
}

function declineChat() {
  document.getElementById('chatRulesModal').style.display = 'none';
  window._pendingChatLink = null;
}
